var AlignTokensOption_8cs =
[
    [ "AlignTokensOption", "AlignTokensOption_8cs.html#a38cd58f84802a5b42be8758813f1287d", [
      [ "AlignIndentationOfTokensToBaseToken", "AlignTokensOption_8cs.html#a38cd58f84802a5b42be8758813f1287daad5ca9d140d377aafc8052cc44a61669", null ],
      [ "AlignPositionOfTokensToIndentation", "AlignTokensOption_8cs.html#a38cd58f84802a5b42be8758813f1287da98b3e70751081ce487eb4da4d1dac661", null ],
      [ "AlignToFirstTokenOnBaseTokenLine", "AlignTokensOption_8cs.html#a38cd58f84802a5b42be8758813f1287da96fd319c5144034c4f09c725d6326a4e", null ]
    ] ]
];