var classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14487 =
[
    [ "ClrType14487", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14487.html#a2b0a82074ff282af3983f84c6c8ab99b", null ],
    [ "m0", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14487.html#a5c213df87fe5f3494dd018d20ad51371", null ],
    [ "m1", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14487.html#a48443bb40af29eec1b1cbe06f4f9c7c8", null ]
];