var classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14494__OldVersion =
[
    [ "ukd", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14494__OldVersion.html#aa3b2dccbbe822da4dc0d704d181c687f", null ],
    [ "ExtensionData", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14494__OldVersion.html#ac6b180df6edff9c23924c92e61b168bd", null ]
];