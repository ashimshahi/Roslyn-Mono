var AdjustNewLinesOption_8cs =
[
    [ "AdjustNewLinesOption", "AdjustNewLinesOption_8cs.html#a9fab3054081675a03b39ed6ed4d3e5c4", [
      [ "PreserveLines", "AdjustNewLinesOption_8cs.html#a9fab3054081675a03b39ed6ed4d3e5c4a1af66c6dd1a5c72d299d218174c5058d", null ],
      [ "ForceLines", "AdjustNewLinesOption_8cs.html#a9fab3054081675a03b39ed6ed4d3e5c4ad4e4dce67960d4c7f666061de780a924", null ],
      [ "ForceIfSameLine", "AdjustNewLinesOption_8cs.html#a9fab3054081675a03b39ed6ed4d3e5c4ab5f10ddade3f7aca65e09344b4b818db", null ]
    ] ]
];