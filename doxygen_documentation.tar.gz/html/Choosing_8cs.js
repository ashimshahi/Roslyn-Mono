var Choosing_8cs =
[
    [ "Choosing", "classMicrosoft_1_1CodeAnalysis_1_1CSharp_1_1UnitTests_1_1Symbols_1_1CorLibrary_1_1Choosing.html", "classMicrosoft_1_1CodeAnalysis_1_1CSharp_1_1UnitTests_1_1Symbols_1_1CorLibrary_1_1Choosing" ],
    [ "CSReferenceManager", "Choosing_8cs.html#a49d11eb02e8a7607ed5a9885b57e3272", null ],
    [ "ProprietaryTestResources", "Choosing_8cs.html#a4d67b28ac82201122cde4fe1af8233d1", null ]
];