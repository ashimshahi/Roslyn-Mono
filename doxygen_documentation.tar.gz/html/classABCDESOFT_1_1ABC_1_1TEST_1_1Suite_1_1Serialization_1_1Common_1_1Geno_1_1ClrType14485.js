var classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14485 =
[
    [ "ClrType14485", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14485.html#a1e9152b74ce434f592efcf5885916bea", null ],
    [ "m0", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14485.html#ab54f36cec1ddadb208186356cd8d69a9", null ],
    [ "m1", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14485.html#a6ab18c18df4e42203df431858d16e8b7", null ]
];