var ApplyChangesKind_8cs =
[
    [ "ApplyChangesKind", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0d", [
      [ "AddProject", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0da7d1e09ccb96c4607f9f1441ce0260ddc", null ],
      [ "RemoveProject", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0dabbb336141b2cc34d1084450faacd8e02", null ],
      [ "AddProjectReference", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0da37e6ff4383a9da28dff623820512b1e6", null ],
      [ "RemoveProjectReference", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0daffdcec5a2c4a727d0389f1bc88bed804", null ],
      [ "AddMetadataReference", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0dacad5752b3c69ddb7df525cbbc1239a12", null ],
      [ "RemoveMetadataReference", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0daa5a9d74cd400f42e9cc3dc7b4c1ea603", null ],
      [ "AddDocument", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0da4587473095689a2e5b3d84cc424e99f2", null ],
      [ "RemoveDocument", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0da78966edc5c9d91b415141b40978a130e", null ],
      [ "ChangeDocument", "ApplyChangesKind_8cs.html#ac70f350aee16b4911dac960bf23f2d0da846d7d04914d6254cf88b8543787af99", null ]
    ] ]
];