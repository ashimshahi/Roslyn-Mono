var classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14495 =
[
    [ "ClrType14495", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14495.html#aef1e4ee3f7c0d0aad0fb62853959ebc4", null ],
    [ "m1", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14495.html#afef0f9697faf49d92b5f9eeaa35992c6", null ]
];