var BoundNodeClassWriter_8cs =
[
    [ "NullHandling", "BoundNodeClassWriter_8cs.html#a8eb21eea0816638e22b2e0932f330418", [
      [ "Allow", "BoundNodeClassWriter_8cs.html#a8eb21eea0816638e22b2e0932f330418a45f0fb72a0defdfdb01de4b5a5a6876b", null ],
      [ "Disallow", "BoundNodeClassWriter_8cs.html#a8eb21eea0816638e22b2e0932f330418a21fd8b5eaad13b449b62b8103bb02a2e", null ],
      [ "Always", "BoundNodeClassWriter_8cs.html#a8eb21eea0816638e22b2e0932f330418a68eec46437c384d8dad18d5464ebc35c", null ],
      [ "NotApplicable", "BoundNodeClassWriter_8cs.html#a8eb21eea0816638e22b2e0932f330418a7599922e28b6009660de5e67f8ce210c", null ]
    ] ],
    [ "TargetLanguage", "BoundNodeClassWriter_8cs.html#ac5f699f7568c7a0e84b347b7a42d317f", [
      [ "VB", "BoundNodeClassWriter_8cs.html#ac5f699f7568c7a0e84b347b7a42d317fa952e108649eee4b686c2431edc8fcd17", null ],
      [ "CSharp", "BoundNodeClassWriter_8cs.html#ac5f699f7568c7a0e84b347b7a42d317fa83925001a044cdfe0c64e9a44345b66d", null ]
    ] ]
];