var AdjustSpacesOption_8cs =
[
    [ "AdjustSpacesOption", "AdjustSpacesOption_8cs.html#a9b2f18b079442036163372d5b673249b", [
      [ "PreserveSpaces", "AdjustSpacesOption_8cs.html#a9b2f18b079442036163372d5b673249bae5f73c6f37ae585dc8126eca25cf4237", null ],
      [ "DefaultSpacesIfOnSingleLine", "AdjustSpacesOption_8cs.html#a9b2f18b079442036163372d5b673249ba0a9a63de9531c7cae5d97ba23037f5e8", null ],
      [ "ForceSpacesIfOnSingleLine", "AdjustSpacesOption_8cs.html#a9b2f18b079442036163372d5b673249ba8d07929227c032789ed7e79a2a0e153a", null ],
      [ "ForceSpaces", "AdjustSpacesOption_8cs.html#a9b2f18b079442036163372d5b673249baac588e9fee4defc62acadabbe602e5bc", null ]
    ] ]
];