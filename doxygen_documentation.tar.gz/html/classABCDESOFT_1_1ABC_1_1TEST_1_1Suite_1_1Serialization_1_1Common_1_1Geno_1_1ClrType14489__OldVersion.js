var classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14489__OldVersion =
[
    [ "ukd", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14489__OldVersion.html#a786148b5f66ed42ee36e75816b35767e", null ],
    [ "ExtensionData", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14489__OldVersion.html#a2bfdcbfcd1fdec2be7c81969dc2b6ed4", null ]
];