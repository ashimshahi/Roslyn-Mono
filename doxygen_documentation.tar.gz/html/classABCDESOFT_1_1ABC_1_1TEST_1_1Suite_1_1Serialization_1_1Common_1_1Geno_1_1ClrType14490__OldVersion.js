var classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14490__OldVersion =
[
    [ "ukd", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14490__OldVersion.html#ac2b9051e5c12e5cdacb8bf35aae1200d", null ],
    [ "ExtensionData", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14490__OldVersion.html#a1745bac2487727cb674ddc99ebf41710", null ]
];