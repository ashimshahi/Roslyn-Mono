var BaseClassTests_8cs =
[
    [ "BaseClassTests", "classMicrosoft_1_1CodeAnalysis_1_1CSharp_1_1UnitTests_1_1BaseClassTests.html", "classMicrosoft_1_1CodeAnalysis_1_1CSharp_1_1UnitTests_1_1BaseClassTests" ],
    [ "Retargeting", "BaseClassTests_8cs.html#adf113dfae1f2d8bc5f9652b1921a39fe", null ]
];