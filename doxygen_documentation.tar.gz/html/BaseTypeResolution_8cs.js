var BaseTypeResolution_8cs =
[
    [ "BaseTypeResolution", "classMicrosoft_1_1CodeAnalysis_1_1CSharp_1_1UnitTests_1_1Symbols_1_1Metadata_1_1PE_1_1BaseTypeResolution.html", "classMicrosoft_1_1CodeAnalysis_1_1CSharp_1_1UnitTests_1_1Symbols_1_1Metadata_1_1PE_1_1BaseTypeResolution" ],
    [ "CSReferenceManager", "BaseTypeResolution_8cs.html#a49d11eb02e8a7607ed5a9885b57e3272", null ]
];