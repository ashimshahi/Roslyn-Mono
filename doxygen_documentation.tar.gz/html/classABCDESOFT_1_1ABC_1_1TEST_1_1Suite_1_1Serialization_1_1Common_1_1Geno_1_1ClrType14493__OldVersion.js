var classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14493__OldVersion =
[
    [ "ukd", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14493__OldVersion.html#aa7814ee0b10c74430f6d095922c91340", null ],
    [ "ExtensionData", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14493__OldVersion.html#a5ddc869385b8515d334628f3f1abe422", null ]
];