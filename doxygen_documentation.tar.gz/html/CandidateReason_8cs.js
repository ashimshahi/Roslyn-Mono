var CandidateReason_8cs =
[
    [ "CandidateReason", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743", [
      [ "None", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "NotATypeOrNamespace", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743aba108c6b8d7ae8403778c415dbd2e362", null ],
      [ "NotAnEvent", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a0213e1b9f3a8f78a26022158f575a432", null ],
      [ "NotAWithEventsMember", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a193397a6d49923107816e6f22b124e56", null ],
      [ "NotAnAttributeType", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a92706f6a369d194934b824f85298806d", null ],
      [ "WrongArity", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a251683f372d99193dab0b5dc418fde81", null ],
      [ "NotCreatable", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a2a8d1185bc1128e9d29e8d01822121b6", null ],
      [ "NotReferencable", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a256ecf2f0be5a02327f40c442d81330c", null ],
      [ "Inaccessible", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a0df94396323447030ba1de8e7e32cb15", null ],
      [ "NotAValue", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a886eb7d3e46ac2d6198b5a1930ff448c", null ],
      [ "NotAVariable", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a1789e86a81d385dbf0a3785c9ecff516", null ],
      [ "NotInvocable", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a6f91fed7d41470ee3d04ab1f55bad051", null ],
      [ "StaticInstanceMismatch", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a2fac16ec8f1739c45558b233f4626c62", null ],
      [ "OverloadResolutionFailure", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743aa5eb9318310fdc3173378adb016a4b9d", null ],
      [ "LateBound", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a82de047bef774772fbfe5076a2fdf9ba", null ],
      [ "Ambiguous", "CandidateReason_8cs.html#a7af2a9e8b3decd229fdccf662416a743a02266588dfd4e565cc42949d0c73f28c", null ]
    ] ]
];