var BinderFlags_8cs =
[
    [ "BinderFlags", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bb", [
      [ "None", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "SuppressConstraintChecks", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbaf34d3d0bbddd51fc613ad3964fb1eb24", null ],
      [ "SuppressObsoleteChecks", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba83beb3c408da443e5bea542688049257", null ],
      [ "ConstructorInitializer", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbac10206651f7d198679c3c8c88958dc5a", null ],
      [ "FieldInitializer", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba60c6bb1ac47447f643bc9e3e70e1c86d", null ],
      [ "ObjectInitializerMember", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbaad4ca0a1d4fe4ec5d5a884f464f34186", null ],
      [ "CollectionInitializerAddMethod", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba5a33c9613f104d39864d9454770a5299", null ],
      [ "AttributeArgument", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba7babaf94c36ce085e7a9461d36dd869b", null ],
      [ "GenericConstraintsClause", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbaaaa3ed3c51f3d967299a0d5b5eed42b0", null ],
      [ "Cref", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbae5cf871e9465b41e64437afc1a529939", null ],
      [ "CrefParameterOrReturnType", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbaf3f95eefcab76ab7060fecc3637e962a", null ],
      [ "UnsafeRegion", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbade8cf38ad7c1e5fa8b2e013fcf144490", null ],
      [ "SuppressUnsafeDiagnostics", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba5153ba893fb7a1aacaf439d5a6795d61", null ],
      [ "SemanticModel", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba3a87d3cbe00bcd31821c6c27e8702eb1", null ],
      [ "EarlyAttributeBinding", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba67833d52fe7627a556dfd2f3d09cbb07", null ],
      [ "CheckedRegion", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba5fd92fb9a1033da98a3e2739b4096e7f", null ],
      [ "UncheckedRegion", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbafb5aae3fff61a6aabbe5589001d23a90", null ],
      [ "InLockBody", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbab730b0dbc266ffc1577305a58dc725b1", null ],
      [ "InCatchBlock", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba4121b186f5ca318fc57d90a3b5d181b2", null ],
      [ "InFinallyBlock", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbaf3ba4c9016cb47b81387cda3d3816197", null ],
      [ "InTryBlockOfTryCatch", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba6a1a2ba5368f815b02d254f42d299dd8", null ],
      [ "InCatchFilter", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba5ba7e2caf571ad69c3ca7c63f0ca4f14", null ],
      [ "SuppressAccessChecks", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba63b0a413a7eddff269e78f9353c63dae", null ],
      [ "AutoPropertyInitializer", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bbaa78584bfe224e7ebdeb7c2104a666024", null ],
      [ "AllClearedAtExecutableCodeBoundary", "BinderFlags_8cs.html#a3bb4f7cffc47f072660851d8e114c5bba8affa9e0c051ea7c5918f9204c7f8c23", null ]
    ] ]
];