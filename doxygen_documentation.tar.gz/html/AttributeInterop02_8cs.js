var AttributeInterop02_8cs =
[
    [ "IEvents", "interfaceEventNS_1_1IEvents.html", "interfaceEventNS_1_1IEvents" ],
    [ "IEvents_Event", "interfaceEventNS_1_1IEvents__Event.html", "interfaceEventNS_1_1IEvents__Event" ],
    [ "NetImpl", "classEventNS_1_1NetImpl.html", "classEventNS_1_1NetImpl" ],
    [ "IOptional", "interfaceEventNS_1_1IOptional.html", "interfaceEventNS_1_1IOptional" ],
    [ "MyEnum", "AttributeInterop02_8cs.html#a57700c3c19857baf337c3a8173bebe5a", [
      [ "zero", "AttributeInterop02_8cs.html#a57700c3c19857baf337c3a8173bebe5aad02c4c4cde7ae76252540d116a40f23a", null ],
      [ "one", "AttributeInterop02_8cs.html#a57700c3c19857baf337c3a8173bebe5aaf97c5d29941bfb1b2fdab0874906ab82", null ],
      [ "two", "AttributeInterop02_8cs.html#a57700c3c19857baf337c3a8173bebe5aab8a9f715dbb64fd5c56e7783c6820a61", null ],
      [ "three", "AttributeInterop02_8cs.html#a57700c3c19857baf337c3a8173bebe5aa35d6d33467aae9a2e3dccb4b6b027878", null ]
    ] ],
    [ "OnEvent01EventHandler", "AttributeInterop02_8cs.html#ae86c95d9ee0962ea263ce57f625fbeed", null ],
    [ "OnEvent02EventHandler", "AttributeInterop02_8cs.html#ad0d7a6a24d334f7a47642f5aef0b01be", null ],
    [ "OnEvent03EventHandler", "AttributeInterop02_8cs.html#aea9f7fae0217410e554654a950a9575e", null ]
];