var AssemblyIdentityParts_8cs =
[
    [ "AssemblyIdentityParts", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6", [
      [ "Name", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6a49ee3087348e8d44e1feda1917443987", null ],
      [ "Version", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6a34b6cd75171affba6957e308dcbd92be", null ],
      [ "VersionMajor", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6a8085f1809e590542d1d919ac063c29f6", null ],
      [ "VersionMinor", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6a6919463f8f5ece712e1281dc895249a5", null ],
      [ "VersionBuild", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6ac3fe0b4f3084838705a92244006307a8", null ],
      [ "VersionRevision", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6ac60a55ae600de1a12390fe993a109284", null ],
      [ "Culture", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6a6926f2fd88f899a22a561f0e808aa8a9", null ],
      [ "PublicKey", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6aaddbd28a071e14f428d003c79304dd18", null ],
      [ "PublicKeyToken", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6a19d45204e31dfe7c341c4f160812a0d7", null ],
      [ "PublicKeyOrToken", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6ae23f7d6fce2f09cd7cd40d17186e7dc9", null ],
      [ "Retargetability", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6a59058f1b2f4babe2609e8052696bb82e", null ],
      [ "ContentType", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6ab8178dd7819d7531e93b9d8112c16e11", null ],
      [ "Unknown", "AssemblyIdentityParts_8cs.html#a356e3c83de865ad0e4423219393b08d6a88183b946cc5f0e8c96b2e66e1c74a7e", null ]
    ] ]
];