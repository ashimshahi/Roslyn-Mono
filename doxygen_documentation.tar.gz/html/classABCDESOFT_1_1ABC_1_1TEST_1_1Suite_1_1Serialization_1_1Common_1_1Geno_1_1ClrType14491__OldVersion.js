var classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14491__OldVersion =
[
    [ "ukd", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14491__OldVersion.html#a02bce2131d351e6c2353b803b837238e", null ],
    [ "ExtensionData", "classABCDESOFT_1_1ABC_1_1TEST_1_1Suite_1_1Serialization_1_1Common_1_1Geno_1_1ClrType14491__OldVersion.html#a8c0f64b6e13102f05972655a91f9e8b9", null ]
];