var AssemblyAndNamespaceTests_8cs =
[
    [ "ContainerTests", "classMicrosoft_1_1CodeAnalysis_1_1CSharp_1_1UnitTests_1_1ContainerTests.html", "classMicrosoft_1_1CodeAnalysis_1_1CSharp_1_1UnitTests_1_1ContainerTests" ],
    [ "ProprietaryTestResources", "AssemblyAndNamespaceTests_8cs.html#a4d67b28ac82201122cde4fe1af8233d1", null ]
];